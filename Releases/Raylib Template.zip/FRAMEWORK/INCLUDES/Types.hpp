#pragma once

#define FRAMEWORK_STATE_SIGNATURE 0x33873B79u
#define PROGRAM_NAME "$projectname$"
#define PROGRAM_VERSION "1.0.0"
#define PROGRAM_IDENTIFIER "com.example.$safeprojectname$"

#include <Program/Code/Types/Program.hpp>

